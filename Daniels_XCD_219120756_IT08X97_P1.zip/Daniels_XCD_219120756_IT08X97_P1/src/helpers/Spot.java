package helpers;

/**
 * @author Daniels XCD 219120756
 *
 */
public class Spot {

	private int yHead;
	private int xHead;
	
	public final int LEFT = 0;
	public final int RIGHT = 1;
	public final int UP = 2;
	public final int DOWN = 3;
	
	private Boolean visited = false;
	private Boolean visitedMove = false;
	private Boolean isBody = false;
	private Boolean isApple = false;
	private Boolean isHead = false;
	
	// Neighbours
	private Spot[] neighbours;

	public Spot(int yHead, int xHead) {
		neighbours = new Spot[4];
		this.yHead = yHead;
		this.xHead = xHead;
	}

	public int getxHead() {
		return xHead;
	}

	public void setxHead(int xHead) {
		this.xHead = xHead;
	}

	public int getyHead() {
		return yHead;
	}

	public void setyHead(int yHead) {
		this.yHead = yHead;
	}

	public Boolean getVisited() {
		return visited;
	}

	public void setVisited(Boolean Visited) {
		visited = Visited;
	}

	public Spot[] getNeighbours() {
		return neighbours;
	}
	
	public Spot getNeighbour(int increment) {
		return neighbours[increment];
	}

	public void setNeighbours(Spot neighbour, int position) {
		neighbours[position] = neighbour;
	}

	public Boolean getIsBody() {
		return isBody;
	}

	public void setIsBody(Boolean isBody) {
		this.isBody = isBody;
	}

//	public Boolean getIsApple() {
//		return isApple;
//	}

	public void setIsApple(Boolean isApple) {
		this.isApple = isApple;
	}

	public Boolean getIsHead() {
		return isHead;
	}

//	public void setIsHead(Boolean isHead) {
//		this.isHead = isHead;
//	}

//	public Boolean getVisitedMove() {
//		return visitedMove;
//	}

	public void setVisitedMove(Boolean visitedMove) {
		this.visitedMove = visitedMove;
	}
}
