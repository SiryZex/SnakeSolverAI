package main;

/**
 * @author Daniels XCD 219120756
 *
 */
public class Main{

	public static void main(String[] args) {
		
		 new GameWorld();
	}
}
