package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Queue;

import javax.swing.JPanel;
import javax.swing.Timer;

import helpers.Pair;
import snakes.*;

public class Panel extends JPanel implements ActionListener {

	static final int SCREEN_WIDTH = 900;
	static final int SCREEN_HEIGHT = 900;
	static final int UNIT_SIZE = 50;
	static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / (UNIT_SIZE * UNIT_SIZE);
	static final int DELAY = 50;

	SnakeGrid grid;

	char direction;
	boolean refresh = true;
	boolean running = false;
	Timer timer;
	
	Queue<Pair> path;

	Panel() {
		this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
		this.setBackground(Color.black);
		this.setFocusable(true);
		startGame();
	}

	public void startGame() {
		grid = new SnakeGrid();
		running = true;
		timer = new Timer(DELAY, this);
		timer.start();
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		draw(g);
	}

	public void draw(Graphics g) {
		if (running) {

			for (int i = 0; i < SCREEN_WIDTH / UNIT_SIZE; i++) {
				g.drawLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT);
				g.drawLine(0, i * UNIT_SIZE, SCREEN_WIDTH, i * UNIT_SIZE);
			}

			g.setColor(Color.red);
			g.fillOval(grid.getPositionApple().getxHead()*UNIT_SIZE,
					   grid.getPositionApple().getyHead()*UNIT_SIZE,
					   UNIT_SIZE, UNIT_SIZE);

			for (int i = 0; i < grid.getPositionBFS().getBodyParts(); i++) {
				if (i == 0) {
					g.setColor(Color.green);
					g.fillRect(grid.getPositionBFS().getX(i)*UNIT_SIZE,
							   grid.getPositionBFS().getY(i)*UNIT_SIZE,
							   UNIT_SIZE, UNIT_SIZE);
				} else {
					g.setColor(new Color(45, 180, 0));
					g.fillRect(grid.getPositionBFS().getX(i)*UNIT_SIZE,
							   grid.getPositionBFS().getY(i)*UNIT_SIZE,
							   UNIT_SIZE, UNIT_SIZE);
				}
			}
			g.setColor(Color.red);
			g.setFont(new Font("Ink Free", Font.BOLD, 40));
			FontMetrics metrics = getFontMetrics(g.getFont());
			g.drawString("Score: " + grid.getPositionBFS().getApplesEaten(),
					(SCREEN_WIDTH - metrics.stringWidth("Score: " + grid.getPositionBFS().getApplesEaten())) / 2,
					g.getFont().getSize());
		} else {
			gameOver(g);
		}
	}

	public void move(Queue<Pair> path) {
		if(!path.isEmpty()) {
			Pair next = path.poll();
			determineMove(next);
			grid.move(direction);
		}else
		{
			refresh = true;
		}
	}
			
	public void determineMove(Pair Current) {
		if (Current.getY_Coordinate() < grid.getPositionBFS().getyHead()) {
			if(direction != 'D') {
				direction = 'U';
			}
		}
		else if (Current.getY_Coordinate() > grid.getPositionBFS().getyHead()) {
			if(direction != 'U') {
				direction = 'D';
			}
		}
		else if (Current.getX_Coordinate() < grid.getPositionBFS().getxHead()) {
			if(direction != 'R') {
				direction = 'L';
			}
		}
		else if (Current.getX_Coordinate() > grid.getPositionBFS().getxHead()) {
			if(direction != 'L') {
				direction = 'R';
			}
		}
	}

	public void checkApple() {

		boolean checkAStar = grid.checkApple();

		if (checkAStar) {
			grid.newApple();
			grid.clearVisited();
			grid.clearVisitedMove();
			refresh = true;
		}
	}

	public Boolean checkCollisions() {
		if (grid.checkCollisions()) {
			return true;
		} else {
			return false;
		}
	}

	public void gameOver(Graphics g) {
		
		// Score
		g.setColor(Color.red);
		g.setFont(new Font("Ink Free", Font.BOLD, 40));
		FontMetrics metrics1 = getFontMetrics(g.getFont());
		g.drawString("Score: " + grid.getPositionBFS().getApplesEaten(),
				(SCREEN_WIDTH - metrics1.stringWidth("Score: " + grid.getPositionBFS().getApplesEaten())) / 2,
				 g.getFont().getSize());

		// Game Over text
		g.setColor(Color.red);
		g.setFont(new Font("Ink Free", Font.BOLD, 75));
		FontMetrics metrics2 = getFontMetrics(g.getFont());
		g.drawString("Game Over", (SCREEN_WIDTH - metrics2.stringWidth("Game Over")) / 2, SCREEN_HEIGHT / 2);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (running) {
			if(refresh == true) {
				path = grid.BFSPath();
				refresh = false;
			}
			move(path);
			checkApple();
			running = checkCollisions();
		}
		if (!running) {
			timer.stop();
		}
		repaint();
	}
}