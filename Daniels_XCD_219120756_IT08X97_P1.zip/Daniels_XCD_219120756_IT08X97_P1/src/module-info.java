/**
 * 
 */
/**
 * @author Sir_Zex
 *
 */
module Daniels_XCD_219120756_IT08X97_P1 {
	requires java.desktop;
}