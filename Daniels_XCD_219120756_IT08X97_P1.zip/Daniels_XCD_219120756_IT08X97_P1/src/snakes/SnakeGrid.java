package snakes;

import java.util.*;

import helpers.Pair;
import helpers.ReadFile;
import helpers.Spot;

/**
 * @author Daniels XCD 219120756
 *
 */
public class SnakeGrid {
	
	private static final int Rows = 18; //Y Value
	private static final int Cols = 18; //X Value

	Random random;
	private Spot[][] grid;
	private static BFS_snake PositionBFS;
	private static Spot PositionApple;

	public SnakeGrid(){
		grid = ReadSpots();
		LinkSpots();
		random = new Random();
	}

	private Spot[][] ReadSpots() {
		int[][] GridStart = ReadFile.ReadFileData();
		Spot[][] SpotData = new Spot[Rows][Cols];
		
		for (int r=0; r < Rows; r++) {
			for (int c=0; c < Cols; c++) {
            	if(GridStart[r][c] == 4) {
            		PositionBFS = new BFS_snake(r, c);
            		PositionBFS.setY(0,0);
            		PositionBFS.setX(0,0);
            		SpotData[r][c] = PositionBFS;
            	}else if(GridStart[r][c] == 10) {
            		PositionApple = new Spot(r, c);
            		SpotData[r][c] = PositionApple;
            	}else {
            		SpotData[r][c] = new Spot(r, c);
            	}
            }
         }
		return SpotData;
	}
	
	private void LinkSpots() {
		for (int r = 0; r < Rows; r++) {
			for (int c = 0; c < Cols; c++) {
				if (r >= 0 && r < Rows && c >= 0 && c < Cols) {
					if (c - 1 >= 0) {
						grid[r][c].setNeighbours(grid[r][c - 1], grid[r][c].LEFT);
					}
					if (c + 1 < Cols) {
						grid[r][c].setNeighbours(grid[r][c + 1], grid[r][c].RIGHT);
					}
					if (r - 1 >= 0) {
						grid[r][c].setNeighbours(grid[r - 1][c], grid[r][c].UP);
					}
					if (r + 1 < Rows) {
						grid[r][c].setNeighbours(grid[r + 1][c], grid[r][c].DOWN);
					}
				}
			}
		}
	}
	
	 // Utility function to find path from source to destination
    private static void BFSPath(Spot node, Queue<Pair> path)
    {
        if (node != null) {
        	int x = PositionApple.getxHead();
        	int y = PositionApple.getyHead();
        	
        	if(node.getNeighbour(node.LEFT) != null //&& x <= node.getNeighbour(node.LEFT).getxHead()
        			&& y == node.getyHead()) {
	            BFSPath(node.getNeighbour(node.LEFT), path);
	            Pair prev = new Pair(node.getyHead(), node.getxHead());
	            path.add(prev);
        	}
//        	else if(node.getNeighbour(node.RIGHT) != null //&& x < node.getNeighbour(node.RIGHT).getxHead()
//        			&& y == node.getyHead()) {
//	            BFSPath(node.getNeighbour(node.RIGHT), path);
//	            Pair prev = new Pair(node.getyHead(), node.getxHead());
//	            path.add(prev);
//        	}
        	else if(node.getNeighbour(node.UP) != null //&& y <= node.getNeighbour(node.UP).getyHead()
        			&& x == node.getxHead()) {
        		BFSPath(node.getNeighbour(node.UP), path);
        		Pair prev = new Pair(node.getyHead(), node.getxHead());
        		path.add(prev);
        	}
//        	else if(node.getNeighbour(node.DOWN) != null //&& y < node.getNeighbour(node.DOWN).getyHead()
//        			&& x == node.getxHead()) {
//        		BFSPath(node.getNeighbour(node.DOWN), path);
//        		Pair prev = new Pair(node.getyHead(), node.getxHead());
//        		path.add(prev);
//        	}
        }
    }
 
    // Find the shortest route in a matrix from source cell (x, y) to
    // destination cell of apple
    public Queue<Pair> BFSPath()
    {
        // list to store shortest path
    	Queue<Pair> path = new ArrayDeque<>();
 
        // create a queue and enqueue the first node
        Queue<Spot> q = new ArrayDeque<>();
        q.add(PositionBFS);
 
        // set to check if the matrix cell is visited before or not
        Set<String> visited = new HashSet<>();
 
        String key = PositionBFS.getxHead() + "," + PositionBFS.getyHead();
        visited.add(key);
 
        // loop till queue is empty
        while (!q.isEmpty())
        {
            // dequeue front node and process it
            Spot current = q.poll();
            int x = current.getxHead(), y = current.getyHead();
 
            // return if the destination is found
            if (x == PositionApple.getxHead() && y == PositionApple.getyHead()) {
                BFSPath(current, path);
                return path;
            }
 
            // check all four possible movements from the current cell
            // and recur for each valid movement
            for (int k = 0; k < current.getNeighbours().length; k++)
            {
            	if (current.getNeighbour(k) != null) {
	            	Spot neighbour = current.getNeighbour(k);
	                key = neighbour.getxHead() + "," + neighbour.getyHead();
	 
	                    // if it isn't visited yet
	                if (!visited.contains(key))
	                {
	                    // enqueue it and mark it as visited
	                    q.add(neighbour);
	                    visited.add(key);
	                }
            	}
            }
        }
 
        // we reach here if the path is not possible
        return path;
    }
	
	public boolean checkApple() {
		
		if ((PositionBFS.getyHead() == PositionApple.getyHead()) &&
			(PositionBFS.getxHead() == PositionApple.getxHead())) {
			
			PositionBFS.plusBodyParts();
			PositionBFS.plusApplesEaten();
			grid[PositionApple.getyHead()][PositionApple.getxHead()] = new Spot(PositionApple.getyHead(),
																				PositionApple.getxHead());
			
			grid[PositionApple.getyHead()][PositionApple.getxHead()].setIsApple(false);
			return true;
		} else {
			return false;
		}
	}
	
	public void newApple() {
		int low = 1;
		int high = 16;
		int appleY = random.nextInt(high-low) + low;
		int appleX = random.nextInt(high-low) + low;
		
		while((grid[appleY][appleX].getIsBody() == true) &&
			  (grid[appleY][appleX].getIsHead() == true)) {
			appleY = random.nextInt(high-low) + low;
			appleX = random.nextInt(high-low) + low;
		}
		
		PositionApple = new Spot(appleY, appleX);
		grid[appleY][appleX] = PositionApple;
		grid[appleY][appleX].setIsApple(true);
	}

	public void clearVisited() {
		for (int r = 0; r < Rows; r++) {
			for (int c = 0; c < Cols; c++) {
				if(r != PositionBFS.getyHead() &&
				   c != PositionBFS.getxHead()) {
				grid[r][c].setVisited(false);
				}
			}
		}
	}
	
	public void clearVisitedMove() {
		for (int r = 0; r < Rows; r++) {
			for (int c = 0; c < Cols; c++) {
				if(r != PositionBFS.getyHead() &&
				   c != PositionBFS.getxHead()) {
				grid[r][c].setVisitedMove(false);
				}
			}
		}
	}
	
	public void move(char direction) {
		for (int i = PositionBFS.getBodyParts(); i > 0; i--) {
			if( i == PositionBFS.getBodyParts()) {
				grid[PositionBFS.getY(PositionBFS.getBodyParts() -1)][PositionBFS.getX(PositionBFS.getBodyParts() - 1)].setIsBody(false);
			}
			PositionBFS.setY(i, PositionBFS.getY(i - 1));
			PositionBFS.setX(i, PositionBFS.getX(i - 1));
		}
		
		for (int i = PositionBFS.getBodyParts(); i > 0; i--) {
			grid[PositionBFS.getY(i)][PositionBFS.getX(i)].setIsBody(true);
		}
		
		switch (direction) {
		
		case 'U':
			int yU = PositionBFS.getyHead();
			int xU = PositionBFS.getxHead();
			
			if (yU - 1 < 0) {
				PositionBFS.setY(0, 17);
				PositionBFS.setyHead(17);
				setCoordinate(17, xU, PositionBFS);
				setCoordinate(yU, xU, new Spot(yU, xU));
			}
			else {
				PositionBFS.setY(0, PositionBFS.getY(0) - 1);
				PositionBFS.setyHead(yU - 1);
				setCoordinate(yU - 1, xU, PositionBFS);
				setCoordinate(yU, xU, new Spot(yU, xU));
			}

			break;
			
		case 'D':
			int yD = PositionBFS.getyHead();
			int xD = PositionBFS.getxHead();
			
			if (yD + 1 > 17) {
				PositionBFS.setY(0, 0);
				PositionBFS.setyHead(0);
				setCoordinate(0, xD, PositionBFS);
				setCoordinate(yD, xD, new Spot(yD, xD));
			}
			else {
				PositionBFS.setY(0, PositionBFS.getY(0) + 1);
				PositionBFS.setyHead(yD + 1);
				setCoordinate(yD + 1, xD, PositionBFS);
				setCoordinate(yD, xD, new Spot(yD, xD));
			}

			break;
			
		case 'L':
			int xL = PositionBFS.getxHead();
			int yL = PositionBFS.getyHead();
			
			if (xL - 1 < 0) {
				PositionBFS.setX(0, 17);
				PositionBFS.setxHead(17);
				setCoordinate(yL, 17, PositionBFS);
				setCoordinate(yL, xL, new Spot(yL, xL));
			}
			else {
				PositionBFS.setX(0, PositionBFS.getX(0) - 1);
				PositionBFS.setxHead(xL - 1);
				setCoordinate(yL, xL - 1, PositionBFS);
				setCoordinate(yL, xL, new Spot(yL, xL));
			}
			break;
			
		case 'R':
			int xR = PositionBFS.getxHead();
			int yR = PositionBFS.getyHead();
			
			if (xR + 1 > 17) {
				PositionBFS.setX(0, 0);
				PositionBFS.setxHead(0);
				setCoordinate(yR, 0, PositionBFS);
				setCoordinate(yR, xR, new Spot(yR, xR));
			}
			else {

				PositionBFS.setX(0, PositionBFS.getX(0) + 1);
				PositionBFS.setxHead(xR + 1);
				setCoordinate(yR, xR + 1, PositionBFS);
				setCoordinate(yR, xR, new Spot(yR, xR));
			}
			break;
		}
	}
	
	public Boolean checkCollisions() {
		// checks if head collides with body
		for (int i = PositionBFS.getBodyParts(); i > 0; i--) {
			if ((PositionBFS.getY(0) == PositionBFS.getY(i)) &&
				(PositionBFS.getX(0) == PositionBFS.getX(i))) {
				return false;
			}
		}
		return true;
	}


	public void setCoordinate(int gridY, int gridX, Spot Value) {
		grid[gridY][gridX] = Value;
	}
	
	public BFS_snake getPositionBFS() {
		return PositionBFS;
	}

	public Spot getPositionApple() {
		return PositionApple;
	}

	public void setPositionApple(int y, int x) {
		PositionApple.setyHead(y);
		PositionApple.setxHead(x);
	}

	public static int getCols() {
		return Cols;
	}

	public static int getRows() {
		return Rows;
	}

	public Spot[][] getGrid() {
		return grid;
	}
}
